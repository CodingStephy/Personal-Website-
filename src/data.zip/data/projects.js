const projects = [
  {
    title: "The Kizuna Archive",
    subtitle: `A website for a Chicago-based commemoration project for the 2011 earthquake and tsunami in Japan, remembering the victims of disaster and documenting the region's recovery`,
    image:
      "https://res.cloudinary.com/dt5zbnwvr/image/upload/v1626143960/Screen_Shot_2021-07-12_at_9.35.07_PM_wk06lf.png",
    color: "#8B0000",
  },
  {
    title: "The Lord of the Rings Website",
    subtitle:
      "A fun responsive website that uses Jquery to document thee adventure in The Lord of the Rings",
    image:
      "https://res.cloudinary.com/dt5zbnwvr/image/upload/v1626145150/Screen_Shot_2021-07-12_at_9.56.43_PM_tzxfhc.png",
    color: "#325044",
  },
  {
    title: "Startup Matchmaker",
    subtitle:
      "Using HTML and CSS flexbox to imitate the layout of the Startup Matchmaker webpage, a website that helps you find the perfect match for your startup.",
    image:
      "https://res.cloudinary.com/dt5zbnwvr/image/upload/v1626294082/Screen_Shot_2021-07-14_at_3.13.00_PM_e9v35g.png",
    color: "#f2aa00",
  },
];

export default projects;
