const skills = [
  {
    name: "HTML",
    percentage: 80,
  },
  {
    name: "CSS",
    percentage: 90,
  },
  {
    name: "Bootstrap",
    percentage: 85,
  },
  {
    name: "JavaScript",
    percentage: 90,
  },
  {
    name: "React",
    percentage: 90,
  },
  {
    name: "Node.js",
    percentage: 70,
  },
  {
    name: "Express",
    percentage: 60,
  },
  {
    name: "MongoDB",
    percentage: 75,
  },
  {
    name: "MySQL",
    percentage: 85,
  },
  {
    name: "Git",
    percentage: 95,
  },
  {
    name: "GitHub",
    percentage: 100,
  },
  {
    name: "Ruby",
    percentage: 70,
  },
  {
    name: "Ruby on Rails",
    percentage: 65,
  },
  {
    name: "Python",
    percentage: 60,
  },
  {
    name: "Figma",
    percentage: 100,
  },
];

export default skills;
